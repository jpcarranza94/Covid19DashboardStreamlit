# friendly-system
A view on Covid 19 with a Dashboard on shiny and Airflow
